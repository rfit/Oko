# PWA:

- Indtast af data, 3 felter.
- Login med People. (Men bodansvarlig giver rettighedder til medarbejdere så de kan oprette)
- Bodansvarlig skal vælge kg/Kr (kg giver mening)
- Festival / Fødevarestyrelsen skal have adgang til noget data.
- Advarelser hvis boder ikke opdatere data, samt har en meget lav øko procent.
- Fælles rapport / dashbord overblik over boder, og festival.

# Data

Hver bod har 1-3 faktura om dagen i gennemsnit, max.

### Data på indtastning
- Dato-tid
- Billag / Faktura nummber
- Samlet beløb/vægt
- Andel som ikke er omfattet
- Andel som er økologisk
- (Nice To Have) Faktura som billede bilag



  <ListItem
		key={index}
		{...{ to: menu.link }}
		component={Link}
		button={true}
	>
